namespace AutoWinner {
	void Run();
}