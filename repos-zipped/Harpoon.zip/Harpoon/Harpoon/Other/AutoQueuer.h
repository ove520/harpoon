#pragma once

namespace AutoQueuer {
	void Run();
}